词轮完整灾备包 v1
仅一个固定ZIP覆盖式归档；先验证新旧内容，异常保留旧包，不变跳过。
需要Node24；无npm依赖。legacy-baseline.json是首次可信的升级前状态，每次必须原样携带，不得替换为新空库。
1. 三个工具verify-backup.mjs、restore-backup.mjs、pack-backup.mjs的SHA256必须匹配自动化保存的可信值，不能只信包内manifest自报。
2. node verify-backup.mjs --new candidate.zip --old previous.zip --legacy-baseline previous.zip
3. node restore-backup.mjs --snapshot candidate.zip 只在全新临时SQLite中恢复验证并删除，不连接生产。
4. 仅decision=approve且隔离恢复成功，才以expected_current_version替换固定Space文件；unchanged不上传，reject保留旧并通知。固定旧文件不存在或损坏则停止，不重新建基线。
首次完整包须用已核验的真实v3基线：node pack-backup.mjs --snapshot candidate.json --legacy-baseline trusted-v3.json --out candidate.zip；后续--legacy-baseline previous.zip。
包含11张应用表、完整内置词库、迁移SQL和版本指纹；不含API key、站点服务凭据或浏览器未同步队列。
生产恢复须另行授权并协调旧客户端队列；不可用状态迁移导入接口代替本包的全库恢复。恢复owner固定site-owner。
